﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    public static class date
    {
        public static int id { get; set;}
        public static string name { get; set;}
        public static string ip { get; set;}
        public static string services { get; set;}
        public static int? id_role { get; set;}
    }
}
