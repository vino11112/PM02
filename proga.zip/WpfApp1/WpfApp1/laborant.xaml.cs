﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для laborant.xaml
    /// </summary>
    public partial class laborant : Window
    {
        public laborant()
        {
            InitializeComponent();
            LoadUserData();
        }
        private void LoadUserData()
        {
            // Пример данных пользователя (обычно берутся из БД или системы аутентификации)
           

            // Устанавливаем значения в Label и Image
            name.Content = $"{date.name} ";
            Role.Content=date.id_role;
        
           // UserRoleLabel.Content = user.Role;

//            try
  //          {
    //            UserPhoto.Source = new BitmapImage(new Uri(user.PhotoPath));
      //      }
        //    catch
          //  {
           //     UserPhoto.Source = new BitmapImage(new Uri("pack://application:,,,/Images/default_photo.jpg"));
           // }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

     
    }
}
