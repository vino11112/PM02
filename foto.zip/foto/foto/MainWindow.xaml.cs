﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace foto
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        labaEntities a = new labaEntities();
        public MainWindow()
        {
            InitializeComponent();
        }
      
        private byte[] imageBytes;
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog
            {
                Filter = "Images (*.jpg, *.png)|*.jpg;*.png"
            };

            if (dialog.ShowDialog() == true)
            {
                try
                {
                    imageBytes = File.ReadAllBytes(dialog.FileName);
                    imgPreview.Source = new BitmapImage(new Uri(dialog.FileName));
             
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}");
                }
            }
        }
        private async void SaveToDatabase_Click(object sender, RoutedEventArgs e)
        {
            if (imageBytes == null)
            {
                MessageBox.Show("Сначала выберите изображение!");
                return;
            }

            string connectionString = "Server=HOME-PC4\\SQLEXPRESS;Database=laba;Integrated Security=True;";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "UPDATE Users SET foto = @Photo WHERE id BETWEEN 181 AND 184";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.Add("@Photo", System.Data.SqlDbType.VarBinary).Value = imageBytes;
                        command.ExecuteNonQuery();
                    }
                }

                txtStatus.Text = "Изображение сохранено в БД!";
                imageBytes = null;
                imgPreview.Source = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}");
            }
        }
    }
}
